
map_data = {
    'A': ['B', 'C'],
    'B': ['A', 'C', 'D'],
    'C': ['A', 'B', 'D'],
    'D': ['B', 'C']
}

colors = ["red", "green", "blue"]

def is_consistent(region, color, assignment):
    for neighbor in map_data[region]:
        if neighbor in assignment and assignment[neighbor] == color:
            return False
    return True

def solve_map(assignment):

    if len(assignment) == len(map_data):
        return assignment

    # Choose the next uncolored region
    for region in map_data:
        if region not in assignment:
            break

    # Try each color
    for color in colors:
        if is_consistent(region, color, assignment):
            assignment[region] = color

            result = solve_map(assignment)

            if result is not None:
                return result

            # Backtracking
            del assignment[region]

    return None

solution = solve_map({})

print("Solution:")

if solution:
    for region, color in solution.items():
        print(region, "=", color)
else:
    print("No solution found")
