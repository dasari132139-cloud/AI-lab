
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB

messages = [
    "Win a free prize now",
    "Claim your free reward",
    "Congratulations you won cash",
    "Get a special offer today",
    "Please attend the meeting tomorrow",
    "Can we meet after class",
    "Your assignment is due Friday",
    "Please please send me the notes"
]

labels = [
    "Spam",
    "Spam",
    "Spam",
    "Spam",
    "Not Spam",
    "Not Spam",
    "Not Spam",
    "Not Spam"
]

# Convert text into numerical data
vectorizer = CountVectorizer()
X = vectorizer.fit_transform(messages)

print("Vocabulary:", vectorizer.vocabulary_)
print(X.toarray())

# Create and train the model
model = MultinomialNB()
model.fit(X, labels)

# Test a new message
new_message = ["Win cash today"]

new_X = vectorizer.transform(new_message)
prediction = model.predict(new_X)

print("Message:", new_message[0])
print("Prediction:", prediction[0])

# Enter your own message
user_message = input("Enter a message: ")

user_X = vectorizer.transform([user_message])
prediction = model.predict(user_X)

print("Prediction:", prediction[0])
