def laptop_expert(turns_on, internet_works, is_slow):
    if turns_on == "no":
        return "Check power cable of the laptop"
    elif internet_works == "no":
        return "Check WiFi and restart the router"
    elif is_slow == "yes":
        return "Close unused programs and restart the system"
    else:
        return "No common problem in the expert system"

turns_on = input("Does the laptop turn on? yes/no: ").lower()
internet_works = input("Does the internet work? yes/no: ").lower()
is_slow = input("Is the laptop slow? yes/no: ").lower()

advice = laptop_expert(turns_on, internet_works, is_slow)

print("\nExpert System Advice")
print(advice)

a = 'PYTHON'
print(a)

b = a.lower()
print(b)